package dungeonmania.entities.enemies;

import dungeonmania.Game;

public interface Movement {

    public void move(Game game);
}
