package dungeonmania.entities.collectables;

import dungeonmania.entities.inventory.InventoryItem;
import dungeonmania.util.Position;

public class Sunstone extends Collectable implements InventoryItem {
    public Sunstone(Position position) {
        super(position);
    }
}
